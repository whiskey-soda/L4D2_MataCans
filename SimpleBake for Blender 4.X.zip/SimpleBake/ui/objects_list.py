import bpy
from ..utils import find_closest_obj, show_message_box, disable_impossible
from bpy.utils import register_class, unregister_class
from bpy.types import Operator, PropertyGroup, UIList
from bpy.props import EnumProperty, StringProperty



def refresh_bake_objects_list():
    
    sbp = bpy.context.scene.SimpleBake_Props
    objects_list = sbp.objects_list

    gone = []
    for li in objects_list:
        #Is it empty?
        if li.obj_point == None:
            gone.append(li.name)

        #Is it no longer in the scene?
        elif li.obj_point.name not in bpy.context.scene.objects:
            gone.append(li.name)

        #Is it not in use anywhere else?
        elif len(li.obj_point.users_scene) < 1:
            gone.append(li.name)

        elif sbp.selected_s2a or sbp.cycles_s2a:
            if sbp.s2a_opmode=="automatch" and sbp.auto_match_mode == "name":
                for o in sbp.objects_list:
                    if o.obj_point != None and not o.obj_point.name.lower().endswith("_high"):
                        gone.append(o.name)
    for g in gone:
        objects_list.remove(objects_list.find(g))
        #We were the only user (presumably)
        #if g in bpy.data.objects:
            #bpy.data.objects.remove(bpy.data.objects[g])

    for i in objects_list:
        i.name = i.obj_point.name

class SIMPLEBAKE_UL_Objects_List(UIList):
    """Bake objects list"""

    viable_high_low_bakes = []

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):

        sbp = context.scene.SimpleBake_Props
        custom_icon = 'OBJECT_DATAMODE'
        name = item.obj_point.name if item.obj_point != None else "_?_"
        target_obj = "???"

        #Set the icon if in name mode
        if (sbp.selected_s2a or sbp.cycles_s2a) and item.obj_point != None:
            if sbp.s2a_opmode=="automatch":
                if sbp.auto_match_mode == "name":
                    custom_icon = "SEQUENCE_COLOR_01"
                    target_obj = "???"

                    for o in bpy.context.scene.objects:
                        if name.lower().replace("_high", "_low") == o.name.lower():
                            target_obj = o.name
                            custom_icon = "SEQUENCE_COLOR_04"
                            if name not in __class__.viable_high_low_bakes:
                                    __class__.viable_high_low_bakes.append(name)

                    #We didn't find a match
                    if target_obj == "???":
                        if name in __class__.viable_high_low_bakes:
                            __class__.viable_high_low_bakes.remove(name)

        #Set the icon if in position mode
        if (sbp.selected_s2a or sbp.cycles_s2a) and item.obj_point != None:
            if sbp.s2a_opmode=="automatch":
                if sbp.auto_match_mode == "position":
                    co = find_closest_obj(name)
                    if co != None:
                        custom_icon = "SEQUENCE_COLOR_04"
                        target_obj = co.name
                        if name not in __class__.viable_high_low_bakes:
                            __class__.viable_high_low_bakes.append(name)
                    else:
                        custom_icon = "SEQUENCE_COLOR_01"
                        target_obj = "???"
                        if name in __class__.viable_high_low_bakes:
                            __class__.viable_high_low_bakes.remove(name)

        # Draw
        if self.layout_type in {'DEFAULT', 'COMPACT'}:

            col = layout.column()
            col.label(text=name, icon=custom_icon)
            if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch":
                col = layout.column()
                col.alignment = 'CENTER'
                col.label(text=" --> ")
                col = layout.column()
                icon = "QUESTION" if target_obj == "???" else "CHECKMARK"
                col.label(text=target_obj, icon=icon)

        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon = custom_icon)



class SimpleBake_OT_Add_Bake_Object(Operator):
    """Add selected object(s) to the bake list"""

    bl_idname = "simplebake.add_bake_object"
    bl_label = "Adds a bake object to the list"

    @classmethod
    def poll(cls, context):
        return len(bpy.context.selected_objects)
    
    def execute(self, context):
        sbp = context.scene.SimpleBake_Props

        #Lets get rid of the non-mesh objects from the selections
        [obj.select_set(False) for obj in bpy.data.objects if obj.type != "MESH"]

        #Do we still have an active object?
        if bpy.context.active_object == None:
            #If not, pick one
            bpy.context.view_layer.objects.active = bpy.context.selected_objects[0]

        #Add to list if not already in the list
        objs = bpy.context.selected_objects.copy()

        for obj in objs:
            #If we are in matching high to low mode, only allow adding of _high objects
            if (sbp.selected_s2a or sbp.cycles_s2a):
                if sbp.s2a_opmode=="automatch" and sbp.auto_match_mode == "name":
                    if not obj.name.lower().endswith("_high"):
                        messages = ([
                        f"ERROR: Can't add object {obj.name}",
                        "You  have auto match high and low poly selected and",
                        "you are using name mode.",
                        "Only object names ending in \"_high\" can be added"
                        ])
                        show_message_box(messages, "Errors occured", icon = 'ERROR')
                        continue

            #Only add if not already on the list
            r = [o.name for o in sbp.objects_list if o.name == obj.name]
            if len(r) == 0:
                n = sbp.objects_list.add()    
                n.obj_point = obj
                n.name = obj.name
        
        #Throw in a refresh
        refresh_bake_objects_list()

        if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch":
            if len(SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes)<2:
                sbp.merged_bake = False
        
        return{'FINISHED'}


class SimpleBake_OT_Add_Bake_Object_By_Name(Operator):
    """Add specified object(s) to the bake list"""

    bl_idname = "simplebake.add_bake_object_by_name"
    bl_label = "Adds a bake object to the list"

    override_target_obj_name: StringProperty(default="")

    def execute(self, context):
        sbp = context.scene.SimpleBake_Props

        n = sbp.objects_list.add()
        obj = bpy.data.objects[self.override_target_obj_name]
        n.obj_point = obj
        n.name = obj.name

        return{'FINISHED'}


class SimpleBake_OT_Remove_Bake_Object(Operator):
    """Remove the selected object from the bake list."""

    bl_idname = "simplebake.remove_bake_object"
    bl_label = "Removes a bake object from the list"

    @classmethod
    def poll(cls, context):
        #TODO-------
        return context.scene.SimpleBake_Props.objects_list

    def execute(self, context):
        sbp = context.scene.SimpleBake_Props
        objects_list = sbp.objects_list
        index = sbp.objects_list_index
        #Record it's name
        name = sbp.objects_list[index].name

        objects_list.remove(index)
        sbp.objects_list_index = min(max(0, index - 1), len(objects_list) - 1)
        
        #Throw in a refresh
        refresh_bake_objects_list()

        #Also remove from high low list
        if name in SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes:
            SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes.remove(name)
        if (sbp.selected_s2a or sbp.cycles_s2a) and sbp.s2a_opmode=="automatch":
            if len(SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes)<2:
                sbp.merged_bake = False

        
        return{'FINISHED'}


class SimpleBake_OT_Clear_Bake_Objects_List(Operator):
    """Clear the object list"""

    bl_idname = "simplebake.clear_bake_objects_list"
    bl_label = "Clears the bake object list"

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        sbp = context.scene.SimpleBake_Props
        sbp.objects_list.clear()
        
        #Throw in a refresh
        refresh_bake_objects_list()

        #Clear the high low match list
        SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes = []
        # if len(SIMPLEBAKE_UL_Objects_List.viable_high_low_bakes)<2:
        #     sbp.merged_bake = False
        
        return{'FINISHED'}

class SimpleBake_OT_Move_Bake_Object_List(Operator):
    """Move an object in the list."""

    bl_idname = "simplebake.move_bake_object_list"
    bl_label = "Moves an item in the bake objects list"

    direction: bpy.props.EnumProperty(items=(('UP', 'Up', ""),
                                              ('DOWN', 'Down', ""),))

    @classmethod
    def poll(cls, context):
        return context.scene.SimpleBake_Props.objects_list

    def move_index(self):
        """ Move index of an item render queue while clamping it. """
        sbp = bpy.context.scene.SimpleBake_Props
        index = sbp.objects_list_index
        list_length = len(sbp.objects_list) - 1  # (index starts at 0)
        new_index = index + (-1 if self.direction == 'UP' else 1)

        sbp.objects_list_index = max(0, min(new_index, list_length))

    def execute(self, context):
        sbp = context.scene.SimpleBake_Props
        objects_list = sbp.objects_list
        index = sbp.objects_list_index

        neighbor = index + (-1 if self.direction == 'UP' else 1)
        objects_list.move(neighbor, index)
        self.move_index()
        
        #Throw in a refresh
        refresh_bake_objects_list()
        
        return{'FINISHED'}


class SimpleBake_OT_Refresh_Bake_Object_List(Operator):
    """Refresh the list to remove objects"""

    bl_idname = "simplebake.refresh_bake_object_list"
    bl_label = "Refresh the bake objects list"

    @classmethod
    def poll(cls, context):
        return True


    def execute(self, context):
        refresh_bake_objects_list()
        
        return{'FINISHED'}
    
classes = ([
        SIMPLEBAKE_UL_Objects_List,
        SimpleBake_OT_Add_Bake_Object,
        SimpleBake_OT_Add_Bake_Object_By_Name,
        SimpleBake_OT_Remove_Bake_Object,
        SimpleBake_OT_Clear_Bake_Objects_List,
        SimpleBake_OT_Move_Bake_Object_List,
        SimpleBake_OT_Refresh_Bake_Object_List
        
        ])

def register():
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
