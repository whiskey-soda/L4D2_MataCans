import bpy 
import numpy as np
import os
from pathlib import Path
import tempfile
import shutil
from bpy.utils import register_class, unregister_class
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty

from ..utils import SBConstants, pbr_selections_to_list, select_only_this, force_to_object_mode, blender_refresh
from ..material_management import SimpleBake_OT_Material_Backup as MatManager
from ..messages import print_message
from ..background_and_progress import BakeInProgress as Bip

def sample_nodes_present(obj_name):
    
    seeking = ["ShaderNodeBevel", "ShaderNodeAmbientOcclusion"]
    
    def hunt(node_tree):
        result = False
        nodes = node_tree.nodes
        for n in nodes:
            if n.bl_idname in seeking and len(n.outputs[0].links)>0:
                result = True
                #May as well return here. One positive ends the game
                return result
            if n.bl_idname == "ShaderNodeGroup":
                result = hunt(n.node_tree)
                #Again, may as well return here if there was a positive
                if result:
                    return True
        
        #Because of the above returns, this will be False if we get here
        return result
        
    
    obj = bpy.data.objects[obj_name]
    for slot in obj.material_slots:
        mat = slot.material
        result = hunt(mat.node_tree)
        
        if result:
            return True

    return False


def create_node_group_dummy_nodes(node, node_tree):
    
    nodes = node_tree.nodes
    
    col_input_sockets = [s for s in node.inputs if s.bl_idname == "NodeSocketColor" and len(s.links) == 0]
    float_input_sockets = [s for s in node.inputs if (s.bl_idname == "NodeSocketFloatFactor" or s.bl_idname == "NodeSocketFloat") and len(s.links) == 0]
    vector_input_sockets = [s for s in node.inputs if s.bl_idname == "NodeSocketVector" and len(s.links) == 0]
    
    for s in col_input_sockets:
        val = s.default_value
        rgb = node_tree.nodes.new("ShaderNodeRGB")
        rgb.outputs[0].default_value = val
        node_tree.links.new(rgb.outputs[0], s)
        
    for s in float_input_sockets:
        val = s.default_value
        vnode = node_tree.nodes.new("ShaderNodeValue")
        vnode.outputs[0].default_value = val
        node_tree.links.new(vnode.outputs[0], s)    
        
    return True

def has_node_groups(mat):
    #print_message(f"Testing {mat.name} for node groups")
    node_tree = mat.node_tree
    nodes = node_tree.nodes
    
    prefs = bpy.context.preferences.addons["SimpleBake"].preferences
    ungroup_all = prefs.ungroup_all_node_groups
    result = False

    node_group_nodes = [n for n in nodes if n.bl_idname == "ShaderNodeGroup"]
    for n in node_group_nodes:
        ss = [s for s in n.outputs if s.bl_idname == "NodeSocketShader"
                and len(s.links)>0]
        if len(ss)>0 or ungroup_all: result = True


    # if len(node_group_nodes)>0:
    #     result = True


    return result
#
#
#     prefs = bpy.context.preferences.addons["SimpleBake"].preferences
#     if len(node_group_nodes)>0 and prefs.ungroup_all_node_groups:
#         result = True
#         return result
#
#     for n in node_group_nodes:
#         ss = [s for s in n.outputs if s.bl_idname == "NodeSocketShader"
#               and len(s.links)>0]
#         if len(ss)>0: result = True
    
    #return result

class SimpleBake_OT_PBR_Pre_Bake(Operator):
    """Master backup and remove node groups"""
    bl_idname = "simplebake.pbr_pre_bake"
    bl_label = "Pre bake for PBR (remove node groups)"

    override_target_object_name: StringProperty(default="")

    def pop_node_group(self, context, mat_name):

        material = bpy.data.materials[mat_name]
        node_tree = material.node_tree


        # Find an object using the material
        found_object = None
        for obj in bpy.data.objects:
            if material.name in [slot.material.name for slot in obj.material_slots if slot.material]:
                found_object = obj
                break

        if not found_object:
            return False

        # Select and activate the object
        bpy.context.view_layer.objects.active = found_object
        for obj in bpy.context.selected_objects:
            obj.select_set(False)
        found_object.select_set(True)

        found_space = None
        found_area = None
        found_screen = None


        # Find an available Node Editor space
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'NODE_EDITOR':
                    for space in area.spaces:
                        if space.type == 'NODE_EDITOR' and space.tree_type == 'ShaderNodeTree':
                            found_space = space
                            found_screen = screen
                            found_area = area
                            break
                    if found_space:
                        break
            if found_space:
                break

        # Ensure a Node Editor space was found
        if not found_space or not found_area or not found_screen:
            return False


        found_space.node_tree = node_tree


        # Select all node groups
        prefs = bpy.context.preferences.addons["SimpleBake"].preferences
        ungroup_all = prefs.ungroup_all_node_groups

        for n in node_tree.nodes:
            ss = [s for s in n.outputs if s.bl_idname == "NodeSocketShader"
                and len(s.links)>0]
            if n.bl_idname == "ShaderNodeGroup" and (len(ss)>0 or ungroup_all) and n.select == False:
                create_node_group_dummy_nodes(n, node_tree)
                n.select = True
            else:
                if n.select == True:
                    n.select = False

        # Override the context to use the found Node Editor space
        override_context = {
            'area': found_area,
            'screen': found_screen,
            'space_data': found_space,
            'region': found_area.regions[-1],  # Assuming the last region is the region type you need
            'window': context.window,
            'edit_tree': node_tree,
            'blend_data': context.blend_data,
            'scene': context.scene,
            'view_layer': context.view_layer,
            'active_object': found_object
        }


        # Perform the ungroup operation within the overridden context
        with context.temp_override(**override_context):
            bpy.ops.node.group_ungroup()

        blender_refresh()

        return True


    def execute(self, context):

        sbp = context.scene.SimpleBake_Props

        #Quick refresh of the bake objects list
        bpy.ops.simplebake.refresh_bake_object_list()

        #Get the list of relevant objects
        if self.override_target_object_name != "":
            objs = [bpy.data.objects[self.override_target_object_name]]
        else:
            objs = [l.obj_point for l in sbp.objects_list]

        #Backup of all materials
        #We ALWAYS want a master backup, so put this ahead of any possible return
        for obj in objs:
            bpy.ops.simplebake.material_backup(
                    target_object_name = obj.name,
                    mode = MatManager.MODE_MASTER_BACKUP)

        #Nope out if this is an image sequence and not the first run
        #if (Bip.running_sequence and not Bip.running_sequence_fist) or Bip.running_sequence_last:
            #print("-----Skipping PBR pre-bake")
            #return {'FINISHED'}

        #Force us into object mode
        force_to_object_mode()



        #Do we actually have any node groups at all? Also skip entirely for Cycles bake
        ngs_present = False
        for obj in objs:
            for slot in obj.material_slots:
                if slot.material != None:
                    if has_node_groups(slot.material):
                        ngs_present = True

        if not ngs_present:
            print_message("No node groups are in play. Proceeding to bake")
            return{'FINISHED'}
        else:
            print_message("Node groups detected. Proceeding to remove them")

        #Get all relevant material names
        mats = []
        for o in objs:
            for slot in o.material_slots:
                if slot.material != None:
                    mats.append(slot.material.name)
        mats = list(set(mats))


        for m_name in mats:
            mat = bpy.data.materials[m_name]

            while has_node_groups(bpy.data.materials[m_name]):

                self.pop_node_group(context, m_name)


        return {'FINISHED'}





class SimpleBake_OT_PBR_Pre_Bake_Old(Operator):
    """Pre bake actions for PBR (remove node groups)"""
    bl_idname = "simplebake.pbr_pre_bake_old"
    bl_label = "Pre bake for PBR (remove node groups) OLD VERSION"

    _timer = None

    #orig_active_mat_indexes = {}

    original_uitype = None
    slot_index = 0
    object_index = 0
    ready_to_bake = False

    @classmethod
    def go_to_bake(cls):
        pass


    def modal(self, context, event):
        sbp = context.scene.SimpleBake_Props

        if event.type == 'TIMER': #Only respond to timer events

            #We are ready to bake
            if self.__class__.ready_to_bake:
                #Remove timer
                wm = context.window_manager
                wm.event_timer_remove(self._timer)

                #Bake
                self.go_to_bake()

                return {'FINISHED'}

            #Finished - no more objects in list
            if self.__class__.object_index > len(sbp.objects_list)-1:

                #Restore the UI
                bpy.context.area.ui_type = self.__class__.original_uitype
                #Bake on next come back
                self.__class__.ready_to_bake = True
                return {'RUNNING_MODAL'}

            #Current obj has more slots, or more objs in list. Either way, press on
            obj = sbp.objects_list[self.__class__.object_index].obj_point
            #If the object we want to work on isn't selected, select it and wait for next timer
            if bpy.context.active_object != obj:
                select_only_this(obj)
                return {'RUNNING_MODAL'}

            #Object we want must be selected - press on

            l = len(obj.material_slots)
            #We've reached the end of the slots - we are done with this object, set for the next and wait for come back
            if self.__class__.slot_index == l:
                self.__class__.slot_index = 0
                self.__class__.object_index += 1
                print_message(f"Finished popping node groups for object '{obj.name}'")
                return {'RUNNING_MODAL'}

            #If the correct mat slot is active, pop the node groups
            elif obj.active_material_index == self.__class__.slot_index:
                mat = obj.material_slots[self.__class__.slot_index].material

                #Ignore empty slot
                if mat == None:
                    self.__class__.slot_index += 1
                    return {'RUNNING_MODAL'}

                print_message(f"Popping node groups for material '{mat.name}' in slot {obj.active_material_index} on object '{obj.name}'")
                node_tree = mat.node_tree
                nodes = node_tree.nodes

                for node in nodes:
                    node.select = False

                for node in nodes:
                    if node.bl_idname == "ShaderNodeGroup":
                        #Get all output sockets that are type shader and linked to something
                        prefs = bpy.context.preferences.addons["SimpleBake"].preferences
                        if prefs.ungroup_all_node_groups:
                            ss = [True] #Hacky! :-(
                        else:
                            ss = [s for s in node.outputs if s.bl_idname == "NodeSocketShader" and len(s.links)>0]

                        if len(ss)>0:
                            #We care about this node group node
                            create_node_group_dummy_nodes(node, node_tree)
                            node.select = True
                            nodes.active = node
                            bpy.ops.node.group_ungroup('INVOKE_DEFAULT')
                            break #Just one per cycle or Blender gets grumpy

                if not has_node_groups(mat): # Only move on when all node groups are gone
                    self.__class__.slot_index += 1 #Incrament slot index by 1 for next time

                return {'RUNNING_MODAL'}

            #If correct mat slot not set, set it and wait to come back
            else:
                obj.active_material_index = self.__class__.slot_index
                return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def execute(self, context):

        sbp = context.scene.SimpleBake_Props

        #Nope out if this is an image sequence and not the first run
        # if (Bip.running_sequence and not Bip.running_sequence_fist) or Bip.running_sequence_last:
        #     print("-----Skipping PBR pre-bake")
        #     return {'FINISHED'}

        print_message("Falling back to old method for ungrouping node groups (Blender 4.0 bug)")


        #Quick refresh of the bake objects list
        bpy.ops.simplebake.refresh_bake_object_list()

        #Force us into object mode
        force_to_object_mode()

        #Get the list of relevant objects
        objs = [l.obj_point for l in sbp.objects_list]

        #Do we actually have any node groups at all? Also skip entirely for Cycles bake
        ngs_present = False
        for obj in objs:
            for slot in obj.material_slots:
                if slot.material != None:
                    if has_node_groups(slot.material):
                        ngs_present = True
        #Start fresh
        for obj in objs:
            for slot in obj.material_slots:
                if slot.material != None:
                    if "SB_master_dup" in slot.material: del slot.material["SB_master_dup"]


        #Backup of all materials
        #We always want a master backup, so put this ahead of any possible return
        for obj in objs:
            bpy.ops.simplebake.material_backup(
                    target_object_name = obj.name,
                    mode = MatManager.MODE_MASTER_BACKUP)

        if not ngs_present:
            print_message("No node groups are in play. Proceeding to bake")
            self.go_to_bake()
            return{'FINISHED'}

        print_message("Going to process materials to remove node groups")



        #Reset variables
        self.__class__.original_uitype = bpy.context.area.ui_type
        self.__class__.slot_index = 0
        self.__class__.object_index = 0
        self.__class__.ready_to_bake = False

        #Set timer and away we go
        bpy.context.area.ui_type = "ShaderNodeTree"
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)

        return {'RUNNING_MODAL'}



class SimpleBake_OT_Invert_Roughness_To_Glossy(Operator):
    """Preperation shared by all types of bake"""
    bl_idname = "simplebake.invert_roughness_to_glossy"
    bl_description = "Invert roughness map to create glossy map"
    bl_label = "Invert"
    
    bake_operation_id: StringProperty()
    bake_mode: StringProperty(default="")
    
    def execute(self, context):
        sbp = bpy.context.scene.SimpleBake_Props

        print_message("Creating glossy image from roughness")
    
        #Find all images that are glossy bakes
        input_images = ([
            i for i in bpy.data.images if
            "SB_bake_operation_id" in i and
            i["SB_bake_operation_id"] == self.bake_operation_id and
            (("SB_glossy_converted" in i and i["SB_glossy_converted"] == False) or
            "SB_glossy_converted" not in i) and
            "SB_this_bake" in i and i["SB_this_bake"] == SBConstants.PBR_GLOSSY
        ])

        #If we are being bake_mode specific, then filter for that
        if self.bake_mode != "":
            input_images = [i for i in input_images if "SB_this_bake" in i and i["SB_this_bake"] == self.bake_mode]

        if len(input_images) == 0:
            return {'FINISHED'}


        for input_image in input_images:
            #Will have been saved externally. Maybe udim, maybe not
            external_path = input_image.filepath

            tiled = True if "<UDIM>" in external_path else False

            if tiled:
                tiles_nums = [t.number for t in input_image.tiles]
                for tile_num in tiles_nums:
                    i = bpy.data.images.load(external_path.replace("<UDIM>", str(tile_num)))
                    i.colorspace_settings.name = input_image.colorspace_settings.name
                    w, h = i.size
                    pixel_data = np.zeros((w, h, 4), 'f')
                    # Fast copy of pixel data from bpy.data to numpy array.
                    i.pixels.foreach_get(pixel_data.ravel())
                    #Invert RGB channels
                    pixel_data[:, :, :3] = 1.0 - pixel_data[:, :, :3]
                    #Output the result and update
                    i.pixels.foreach_set(pixel_data.ravel())
                    i.update()
                    i.save()
                    bpy.data.images.remove(i)

            else:
                #Edit the image directly as it already exists
                w, h = input_image.size
                pixel_data = np.zeros((w, h, 4), 'f')
                input_image.pixels.foreach_get(pixel_data.ravel())
                pixel_data[:, :, :3] = 1.0 - pixel_data[:, :, :3]
                input_image.pixels.foreach_set(pixel_data.ravel())
                input_image.save()

            #Either way, this image isn't caputred again
            input_image.update()
            input_image["SB_glossy_converted"] = True
        
        return {'FINISHED'}

class SimpleBake_OT_Create_Directx_Normal(Operator):
    """Preperation shared by all types of bake"""
    bl_idname = "simplebake.create_directx_normal"
    bl_description = "Flip Y to create DirectX normal map"
    bl_label = "Create"

    bake_operation_id: StringProperty()
    bake_mode: StringProperty(default="")

    def execute(self, context):
        sbp = bpy.context.scene.SimpleBake_Props

        print_message("Creating DirectX normal maps")

        #Find all images that are normal bakes
        input_images = ([
            i for i in bpy.data.images if
            "SB_bake_operation_id" in i and
            i["SB_bake_operation_id"] == self.bake_operation_id and
            (("SB_directx_converted" in i and i["SB_directx_converted"] == False) or
            "SB_directx_converted" not in i) and
            "SB_this_bake" in i and i["SB_this_bake"] == SBConstants.PBR_NORMAL
        ])

        #If we are being bake_mode specific, then filter for that
        if self.bake_mode != "":
            input_images = [i for i in input_images if "SB_this_bake" in i and i["SB_this_bake"] == self.bake_mode]

        if len(input_images) == 0:
            return {'FINISHED'}

        print_message(f"DirectX conversation needed for {input_images}")

        for input_image in input_images:
            #Will have been saved externally. Maybe udim, maybe not
            external_path = input_image.filepath

            tiled = True if "<UDIM>" in external_path else False

            if tiled:
                tiles_nums = [t.number for t in input_image.tiles]
                for tile_num in tiles_nums:
                    i = bpy.data.images.load(external_path.replace("<UDIM>", str(tile_num)))
                    i.colorspace_settings.name = input_image.colorspace_settings.name
                    w, h = i.size
                    pixel_data = np.zeros((w, h, 4), 'f')
                    # Fast copy of pixel data from bpy.data to numpy array.
                    i.pixels.foreach_get(pixel_data.ravel())
                    #Invert G channel
                    pixel_data[:, :, 1] = 1.0 - pixel_data[:, :, 1]
                    #Output the result and update
                    i.pixels.foreach_set(pixel_data.ravel())
                    i.save()
                    bpy.data.images.remove(i)

            else:
                #Edit the image directly as it already exists
                w, h = input_image.size
                pixel_data = np.zeros((w, h, 4), 'f')
                input_image.pixels.foreach_get(pixel_data.ravel())
                #Invert G channel
                pixel_data[:, :, 1] = 1.0 - pixel_data[:, :, 1]
                input_image.pixels.foreach_set(pixel_data.ravel())
                input_image.save()

            #Either way, this image isn't caputred again
            input_image.update()
            input_image["SB_directx_converted"] = True

        return {'FINISHED'}



class SimpleBake_OT_PBR_Specific_Bake_Prep_And_Finish(Operator):
    """Preperation and finishing specific to PBR baking"""
    bl_idname = "simplebake.pbr_specific_bake_prep_and_finish"
    bl_description = "Preperation or Finish for PBR bake type"
    bl_label = "Prepare or Finish"
    
    mode: StringProperty()
    
    orig_sample_count = 0
    
    def finish(self, context):
        #print_message("PBR specific bake finishing actions")
        #Restore original sample count
        context.scene.cycles.samples = self.__class__.orig_sample_count
        
    def prepare(self, context):
        sbp = bpy.context.scene.SimpleBake_Props

        #Store original sample count
        self.__class__.orig_sample_count = context.scene.cycles.samples        
        
        #S2A must be off if not S2A
        if not sbp.selected_s2a:
            bpy.context.scene.render.bake.use_selected_to_active=False
    
    def execute(self, context):
        if self.mode == "prepare":
            self.prepare(context)
        elif self.mode == "finish":
            self.finish(context)
    
        return {'FINISHED'}

class SimpleBake_OT_Remove_Reroutes(Operator):
    bl_idname = "simplebake.remove_reroutes"
    bl_label = "Remove"
    
    
    def execute(self, context):
        sbp = context.scene.SimpleBake_Props

        #Setup
        bpy.ops.simplebake.refresh_bake_object_list()
        force_to_object_mode()
        objs = [l.obj_point for l in sbp.objects_list]
        
        for obj in objs:
            for matslot in obj.material_slots:
                mat = matslot.material
                print_message(f"Removing reroute nodes for material {mat.name}")
                node_tree = mat.node_tree
                nodes = node_tree.nodes
    
                reroute_nodes = [n for n in nodes if n.bl_idname == "NodeReroute"]
    
                for node in reroute_nodes:
                    #Nothing plugged in
                    if len(node.inputs[0].links) == 0:
                        nodes.remove(node)
                        continue
                    
                    #Otherwise...
                    origin_socket = node.inputs[0].links[0].from_socket #Can only be one input
                    output_links = [l for l in node.outputs[0].links]
        
                    for l in output_links:
                        dest_socket = l.to_socket
                        node_tree.links.new(origin_socket, dest_socket)
        
                #Remove all reroute nodes, as now all bypassed
                [nodes.remove(n) for n in nodes if n.bl_idname == "NodeReroute"]
        return {'FINISHED'}

class SimpleBake_OT_Multiply_AO(Operator):
    """Multiple Diffuse by AO"""
    bl_idname = "simplebake.multiply_ao"
    bl_description = "Multiply Diffuse by AO"
    bl_label = "Multiply"

    bake_operation_id: StringProperty()

    def execute(self, context):

        sbp = context.scene.SimpleBake_Props

        #Find all diffuse images for this bake operation ID
        diffuse_images = [i for i in bpy.data.images if\
            "SB_bake_operation_id" in i and\
                i["SB_bake_operation_id"] == self.bake_operation_id and\
                    "SB_this_bake" in i and\
                        i["SB_this_bake"] == SBConstants.PBR_DIFFUSE]

        #Find the AO image
        ao_images = [i for i in bpy.data.images if\
            "SB_bake_operation_id" in i and\
                i["SB_bake_operation_id"] == self.bake_operation_id and\
                    "SB_this_bake" in i and\
                        i["SB_this_bake"] == SBConstants.AO]

        #Pair them up (this also works for merged bake, apprently)
        paired = {}
        for d in diffuse_images:
            o = d["SB_bake_object"]
            matched = [a for a in ao_images if "SB_bake_object" in a and a["SB_bake_object"] == o]
            assert(len(matched) == 1), f"Didn't find exactly one matching AO image for {d.name}"
            paired[d] = matched[0]

        #Import the compositing scene that we needed
        path = os.path.dirname(__file__) + "/../resources/multiply.blend/Scene/"
        if "SBCompositing_Multiply" in bpy.data.scenes:
            bpy.data.scenes.remove(bpy.data.scenes["SBCompositing_Multiply"])
        bpy.ops.wm.append(filename="SBCompositing_Multiply", directory=path)

        #Set up our scene
        scene = bpy.data.scenes["SBCompositing_Multiply"]
        #Set the output resolution of the scene to the texture size we are using
        scene.render.resolution_y = sbp.outputheight
        scene.render.resolution_x = sbp.outputwidth
        nodes = scene.node_tree.nodes

        #Multiply factor will remain consistent
        nodes["Mix"].inputs['Fac'].default_value = sbp.multiply_diffuse_ao_percent * 0.01

        for d in paired:

            tiles_nums = [t.number for t in d.tiles]
            for tile_num in tiles_nums:

                path_d = d.filepath.replace("<UDIM>", str(tile_num))
                path_a = paired[d].filepath.replace("<UDIM>", str(tile_num))

                #Load that tile in as an internal image
                img_d = bpy.data.images.load(path_d)
                img_a = bpy.data.images.load(path_a)

                nodes["Base"].image = img_d
                nodes["Multiplant"].image = img_a

                #Render to temp file for the internal image
                tmpdir = Path(tempfile.mkdtemp())
                scene.render.filepath = str(tmpdir / "tmp")
                #Let's always do this an EXR (lossless compression)
                scene.render.image_settings.file_format = "OPEN_EXR"
                scene.render.image_settings.exr_codec = "ZIP"
                bpy.ops.render.render(animation=False, write_still=True, use_viewport=False, scene=scene.name)

                #Reload the temp file into an internal image again
                img = bpy.data.images.load(str(tmpdir / "tmp")+"."+"exr")
                img.colorspace_settings.name = "Non-Color"
                img.pack()
                shutil.rmtree(str(tmpdir))

                #Save over the original diffuse image in external file system
                s = bpy.data.scenes.new("tmp")

                #Match settings:
                #Colorspace
                img.colorspace_settings.name = d.colorspace_settings.name
                #File format
                s.render.image_settings.file_format = d.file_format
                #Bit depth and compression
                if d.file_format == "OPEN_EXR":
                    s.render.image_settings.color_depth = "32"
                    s.render.image_settings.exr_codec = sbp.exr_codec_export
                elif sbp.everything_16bit:
                    s.render.image_settings.color_depth = "16"
                else:
                    s.render.image_settings.color_depth = "8"
                #Channels
                s.render.image_settings.color_mode = "RGBA" if sbp.use_alpha else "RGB"

                img.save_render(bpy.path.abspath(path_d), scene=s)

                #Clean up
                bpy.data.images.remove(img)
                bpy.data.images.remove(img_d)
                bpy.data.images.remove(img_a)
                bpy.data.scenes.remove(s)

            #Reload the original
            d.reload()

        #Remove the scene for multiplying
        bpy.data.scenes.remove(scene)


        return {'FINISHED'}


classes = ([
    SimpleBake_OT_Invert_Roughness_To_Glossy,
    SimpleBake_OT_Create_Directx_Normal,
    SimpleBake_OT_PBR_Specific_Bake_Prep_And_Finish,
    SimpleBake_OT_PBR_Pre_Bake,
    SimpleBake_OT_PBR_Pre_Bake_Old,
    SimpleBake_OT_Remove_Reroutes,
    SimpleBake_OT_Multiply_AO
        ])

def register():
    
    global classes
    for cls in classes:
        register_class(cls)

def unregister():
    global classes
    for cls in classes:
        unregister_class(cls)
